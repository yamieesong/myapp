import React from 'react'

const Selectcomponent = (props) => {
  console.log('!!!!!!!!!! : ' + props.datalist)

  const dl = [...props.datalist]

  return (
    <div>
      SamplePage4 open <br />
      <select id='dynmaicsel' name='dynmaicsel'>
        <option key='0' value=''>
          전체
        </option>
        {dl.map((item, index) => (
          <option key={index} value={item}>
            {item}
          </option>
        ))}
      </select>
    </div>
  )
}

export default Selectcomponent
